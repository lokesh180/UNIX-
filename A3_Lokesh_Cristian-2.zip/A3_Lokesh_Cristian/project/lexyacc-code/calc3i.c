#include <stdio.h>
#include "calc3.h"
#include "y.tab.h"

static int lbl;

void print(){
    printf("\tmovq\t$format, %%rdi\n");
    printf("\tpopq\t%%rsi\n");
    printf("\txor\t%%rax, %%rax\n");
    printf("\tcall\tprintf\n");
}

void uminus(){
    printf("\tpopq %%rax\n");
    printf("\tneg %%rax\n");
    printf("\tpushq %%rax\n");
}

void fact(){
    printf("\tpopq\t%%rbx\n");
    printf("\tcall fact\n");
	printf("\tpushq\t%%rax\n");
}
void lntwo(){
    printf("\tpopq\t%%rcx\n");
    printf("\tcall lntwo\n");
	printf("\tpushq\t%%rax\n");
}
void gcd(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tcall gcd\n");
    printf("\tpushq\t%%rax\n");
}
void addition(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tadd \t%%rbx, %%rax\n");
    printf("\tpushq\t%%rax\n");
}
void sub(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tsub \t%%rbx, %%rax\n");
    printf("\tpushq\t%%rax\n");
}
void mul(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tmul\t %%rbx\n");
    printf("\tpushq\t%%rax\n");
}
void div(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tcqto\n");
	printf("\tidiv\t%%rbx\n");
    printf("\tpushq\t%%rax\n");
}
void greater(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tmovq\t$0, %%rcx\n");
    printf("\tcmpq\t%%rax, %%rbx\n");
    printf("\tsetg\t%%cl\n");
    printf("\tpushq\t%%rcx\n");
}
void lesser(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tmovq\t$0, %%rcx\n");
	printf("\tcmpq\t%%rax, %%rbx\n");
	printf("\tsetl\t%%cl\n");
	printf("\tpushq\t%%rcx\n");
}
void ge(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tmovq\t$0, %%rcx\n");
    printf("\tcmpq\t%%rax, %%rbx\n");
    printf("\tsetle\t%%cl\n");
    printf("\tpushq\t%%rcx\n");
}
void le(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");  
    printf("\tmovq\t$0, %%rcx\n");
    printf("\tcmpq\t%%rax, %%rbx\n"); 
    printf("\tsetge\t%%cl\n"); 
    printf("\tpushq\t%%rcx\n");
}
void ne(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");  
    printf("\tmovq\t$0, %%rcx\n");
    printf("\tcmpq\t%%rax, %%rbx\n"); 
    printf("\tsetne\t%%cl\n"); 
    printf("\tpushq\t%%rcx\n");
}
void eq(){
    printf("\tpopq\t%%rbx\n");
    printf("\tpopq\t%%rax\n");
    printf("\tmovq\t$0, %%rcx\n");
    printf("\tcmpq\t%%rax, %%rbx\n"); 
    printf("\tsete\t%%cl\n"); 
    printf("\tpushq\t%%rcx\n");
}

int ex(nodeType *p) {
    int lbl1, lbl2;

    if (!p) return 0;

    switch(p->type) {
        case typeCon:       
            printf("\tpushq\t$%d\n", p->con.value);
            break;
        case typeId:        
            printf("\tpushq\t%c\n", p->id.i + 'a');
            break;
        case typeOpr:
            switch(p->opr.oper) {
            case WHILE:
                printf("L%03d:\n", lbl1 = lbl++);
                ex(p->opr.op[0]);
	            printf("\tpopq\t%%rcx\n");
	            printf("\ttest\t%%cx, %%cx\n");
                printf("\tje\tL%03d\n", lbl2 = lbl++);
                ex(p->opr.op[1]);
                printf("\tjmp\tL%03d\n", lbl1);
                printf("L%03d:\n", lbl2);
                break;
            case IF:
                ex(p->opr.op[0]);
                if (p->opr.nops > 2) {
                    /* if else */
                    printf("\tpopq\t%%rcx\n");
                    printf("\tjecxz\tL%03d\n", lbl1 = lbl++); 
                    ex(p->opr.op[1]);
                    printf("\tjmp\tL%03d\n", lbl2 = lbl++);
                    printf("L%03d:\n", lbl1);
                    ex(p->opr.op[2]);
                    printf("L%03d:\n", lbl2);
                } else {
                    /* if */
		            printf("\tpopq\t%%rcx\n");
                    printf("\tjecxz\tL%03d\n", lbl1 = lbl++); 
                    ex(p->opr.op[1]);
                    printf("L%03d:\n", lbl1);
                }
                break;
            case PRINT:     
                ex(p->opr.op[0]);
                print();
                break;
            case '=':       
                ex(p->opr.op[1]);
                printf("\tpopq\t%c\n", p->opr.op[0]->id.i + 'a');
                break;
            case UMINUS:    
                ex(p->opr.op[0]);
                uminus();
                break;
            case FACT:
                ex(p->opr.op[0]);
                fact();
                break;
            case LNTWO:
                ex(p->opr.op[0]);
                lntwo();
                break;
            default:
                ex(p->opr.op[0]);
                ex(p->opr.op[1]);
                switch(p->opr.oper) {
                    case GCD:
                        gcd();
                        break;
                    case '+':
                        addition();
                        break;
                    case '-':
                        sub();
                        break;         
                    case '*':
                        mul();
                        break;
                    case '/':
                        div();
                        break;
                    case '<':
                        greater();
                        break;
                    case '>':
                        lesser();
                        break;
                    case GE:
                        ge();
                        break;
                    case LE:
                        le();
                        break;
                    case NE:
                        ne();
                        break;
                    case EQ:
                        eq();
                        break;
                }
            }
    }

    return 0;
}

