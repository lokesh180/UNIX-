#!/bin/bash
lib="functions"
libdir="./lib"

printUsage()
{
    echo "Usage: $0 <testprogs/filename.calc>"
}

if [ $# != 1 ]; then
	printUsage
	exit
fi

if [[ $1 != *.calc ]]; then
    echo "Invalid File:The file extension should be '.calc'"
    exit
fi

if [ ! -r $1 ]; then
    echo "File doesn't exist"
    exit
fi

file=`echo $1 | rev | cut -d'/' -f1 | rev | cut -d'.' -f1`
assemfile=$file.s

cat prologue.s > $assemfile
./bin/calc3i < $1 >> $assemfile
cat epilogue.s >> $assemfile
echo "Output was sent into the file "$assemfile

gcc -no-pie $assemfile -L $libdir -l $lib -o $file -z noexecstack
